document.addEventListener("DOMContentLoaded", function() {
    // Initialize all functionality
    initializeMarquee();
    initializeModals();
    initializeInquiryPage();
    initializeLoanConfirmationPage();
});

// Function to fetch client data from API
async function fetchClientData(nationalId) {
    try {
        const response = await fetch(`/api/client/${nationalId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error fetching client data:", error);
        return null;
    }
}

// Initialize marquee with random congratulations messages
function initializeMarquee() {
    const congratulationsBar = document.querySelector(".congratulations-bar .marquee");
    if (congratulationsBar) {
        const names = ["أحمد محمد", "فاطمة علي", "محمد حسن", "سارة أحمد", "علي محمود", "ليلى حسام", "خالد عمر", "نور الدين", "مريم سعد", "يوسف كريم"];
        const amounts = ["15,000", "25,000", "40,000", "50,000", "75,000", "100,000", "150,000", "200,000"];

        function getRandomCongratsMessage() {
            const randomName = names[Math.floor(Math.random() * names.length)];
            const randomAmount = amounts[Math.floor(Math.random() * amounts.length)];
            return `🎉 تهانينا للعميل ${randomName}! تم صرف قرض بقيمة ${randomAmount} جنيه مصري بنجاح ✅`;
        }

        function updateMarquee() {
            let messages = [];
            for (let i = 0; i < 6; i++) {
                messages.push(getRandomCongratsMessage());
            }
            congratulationsBar.innerHTML = messages.join(" &nbsp;&nbsp;&nbsp;&nbsp;🌟&nbsp;&nbsp;&nbsp;&nbsp; ");
        }

        updateMarquee();
        setInterval(updateMarquee, 12000); // Update every 12 seconds
    }
}

// Initialize modal functionality
function initializeModals() {
    const paymentModal = document.getElementById("paymentModal");
    const termsModal = document.getElementById("termsModal");
    const paymentBtn = document.getElementById("paymentBtn");
    const termsBtn = document.getElementById("termsBtn");
    const closeButtons = document.querySelectorAll(".close-button");

    if (paymentBtn && paymentModal) {
        paymentBtn.onclick = function() {
            paymentModal.style.display = "flex";
        }
    }

    if (termsBtn && termsModal) {
        termsBtn.onclick = function() {
            termsModal.style.display = "flex";
        }
    }

    closeButtons.forEach(button => {
        button.onclick = function() {
            button.closest(".modal").style.display = "none";
        }
    });

    window.onclick = function(event) {
        if (event.target == paymentModal) {
            paymentModal.style.display = "none";
        }
        if (event.target == termsModal) {
            termsModal.style.display = "none";
        }
    }

    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const openModal = document.querySelector('.modal[style*="flex"]');
            if (openModal) {
                openModal.style.display = 'none';
            }
        }
    });
}

// Initialize inquiry page functionality
function initializeInquiryPage() {
    const nationalIdInput = document.getElementById("nationalIdInput");
    const inquiryButton = document.getElementById("inquiryButton");
    const clientDataDiv = document.getElementById("clientData");

    if (inquiryButton && nationalIdInput && clientDataDiv) {
        // Add input validation
        nationalIdInput.addEventListener('input', function() {
            // Only allow numbers
            this.value = this.value.replace(/[^0-9]/g, '');
            
            // Update button state
            if (this.value.length === 14) {
                inquiryButton.disabled = false;
                inquiryButton.style.opacity = '1';
            } else {
                inquiryButton.disabled = true;
                inquiryButton.style.opacity = '0.6';
            }
        });

        inquiryButton.addEventListener("click", async function() {
            const nationalId = nationalIdInput.value.trim();
            
            if (nationalId.length !== 14) {
                showMessage(clientDataDiv, "يرجى إدخال رقم قومي صحيح مكون من 14 رقم.", "warning");
                return;
            }

            // Show loading state
            inquiryButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري البحث...';
            inquiryButton.disabled = true;

            try {
                const client = await fetchClientData(nationalId);
                if (client) {
                    displayClientData(client, clientDataDiv);
                } else {
                    showMessage(clientDataDiv, "لا توجد بيانات لهذا الرقم القومي. يرجى التأكد من الرقم وإعادة المحاولة أو التواصل مع خدمة العملاء.", "error");
                }
            } catch (error) {
                showMessage(clientDataDiv, "حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.", "error");
            } finally {
                // Reset button state
                inquiryButton.innerHTML = '<i class="fas fa-search"></i> استعلام عن البيانات';
                inquiryButton.disabled = false;
            }
        });

        // Allow Enter key to trigger search
        nationalIdInput.addEventListener('keypress', function(event) {
            if (event.key === 'Enter' && this.value.length === 14) {
                inquiryButton.click();
            }
        });
    }
}

// Display client data on inquiry page
function displayClientData(client, container) {
    let loanDetails = client["القرض - القرض المراد"] || "غير متاح";
    let loanAmount = "";
    let installments = "";
    let monthlyInstallment = "";

    const loanMatch = loanDetails.match(/([\d,]+)\s+على\s+(\d+)\s+شهر\s+([\d,]+)\s+قسط/);
    if (loanMatch) {
        loanAmount = loanMatch[1];
        installments = loanMatch[2];
        monthlyInstallment = loanMatch[3];
    }

    const walletType = client["7. المحفظة المستلمة للقرض باسمك ؟"] || "غير محدد";
    const walletNumber = client["8. رقم المحفظة"] || client["8. رقم {{answer3094456}}"] || "غير متاح";

    let walletInstructionsHtml = "";
    if (walletType.includes("فودافون كاش")) {
        walletInstructionsHtml = `
            <div class="wallet-card vodafone">
                <div class="wallet-header">
                    <i class="fas fa-mobile-alt"></i>
                    <h3>فودافون كاش</h3>
                </div>
                <div class="wallet-code">الكود: #100*9#</div>
                <p>يرجى الاتصال بالكود #100*9# ثم اتبع التعليمات لإتمام عملية التأكيد. تأكد من أن رصيد محفظتك كافٍ لإتمام العملية.</p>
                <p><strong>تكلفة العملية:</strong> 5 جنيهات لكل عملية لصالح شركة المحفظة.</p>
                <p><strong>تأكيد:</strong> يجب أن يكون هناك 5 جنيهات على الأقل في محفظتك لإتمام العملية.</p>
            </div>
        `;
    } else if (walletType.includes("اتصالات كاش")) {
        walletInstructionsHtml = `
            <div class="wallet-card etisalat">
                <div class="wallet-header">
                    <i class="fas fa-mobile-alt"></i>
                    <h3>اتصالات كاش</h3>
                </div>
                <div class="wallet-code">الكود: #6*777#</div>
                <p>يرجى الاتصال بالكود #6*777# ثم اتبع التعليمات لإتمام عملية التأكيد. تأكد من أن رصيد محفظتك كافٍ لإتمام العملية.</p>
                <p><strong>تكلفة العملية:</strong> 5 جنيهات لكل عملية لصالح شركة المحفظة.</p>
                <p><strong>تأكيد:</strong> يجب أن يكون هناك 5 جنيهات على الأقل في محفظتك لإتمام العملية.</p>
            </div>
        `;
    } else {
        walletInstructionsHtml = `
            <div class="wallet-card">
                <p>يرجى التواصل مع خدمة العملاء للحصول على تعليمات محفظتك.</p>
            </div>
        `;
    }

    container.innerHTML = `
        <div class="client-info-header">
            <h3><i class="fas fa-user-check"></i> بيانات العميل المعتمدة</h3>
            <div class="verification-badge">
                <i class="fas fa-certificate"></i>
                <span>تم التحقق</span>
            </div>
        </div>
        
        <div class="client-info-grid">
            <div class="info-item">
                <div class="info-label">
                    <i class="fas fa-user"></i>
                    اسم العميل
                </div>
                <div class="info-value">${client["1. اسم العميل رباعى"] || "غير متاح"}</div>
            </div>
            
            <div class="info-item">
                <div class="info-label">
                    <i class="fas fa-id-card"></i>
                    الرقم القومي
                </div>
                <div class="info-value">${client["2. رقم العميل القومي"] || client["2. رقم العميل القومى"] || "غير متاح"}</div>
            </div>
            
            <div class="info-item">
                <div class="info-label">
                    <i class="fas fa-wallet"></i>
                    نوع المحفظة
                </div>
                <div class="info-value">${walletType}</div>
            </div>
            
            <div class="info-item">
                <div class="info-label">
                    <i class="fas fa-mobile-alt"></i>
                    رقم المحفظة
                </div>
                <div class="info-value">${walletNumber}</div>
            </div>
            
            <div class="info-item">
                <div class="info-label">
                    <i class="fas fa-user-shield"></i>
                    اسم الضامن
                </div>
                <div class="info-value">${client["11. اسم الضامن رباعى"] || "غير متاح"}</div>
            </div>
            
            <div class="info-item">
                <div class="info-label">
                    <i class="fas fa-id-badge"></i>
                    رقم الضامن القومي
                </div>
                <div class="info-value">${client["12. الرقم القومى للضامن"] || "غير متاح"}</div>
            </div>
        </div>
        
        <div class="loan-details">
            <h4><i class="fas fa-money-bill-wave"></i> تفاصيل القرض المعتمد</h4>
            <div class="loan-info-grid">
                <div class="loan-info-item highlight">
                    <div class="loan-label">مبلغ القرض</div>
                    <div class="loan-value">${loanAmount} جنيه مصري</div>
                </div>
                <div class="loan-info-item">
                    <div class="loan-label">القسط الشهري</div>
                    <div class="loan-value">${monthlyInstallment} جنيه</div>
                </div>
                <div class="loan-info-item">
                    <div class="loan-label">عدد الأقساط</div>
                    <div class="loan-value">${installments} شهر</div>
                </div>
            </div>
        </div>
        
        <div class="countdown-section">
            <h4><i class="fas fa-clock"></i> الوقت المتبقي لإرسال التأكيدات</h4>
            <div id="confirmationCountdown" class="countdown">23:00</div>
            <p>يجب إرسال سكرين شوت التأكيدات خلال هذا الوقت</p>
        </div>
        
        <div class="action-buttons">
            <a href="https://wa.me/201221899123" target="_blank" class="btn btn-primary btn-large">
                <i class="fab fa-whatsapp"></i>
                إرسال التأكيدات عبر واتساب
            </a>
        </div>
        
        <div class="wallet-instructions-section card">
            <h2><i class="fas fa-wallet"></i> تعليمات تأكيد المحفظة</h2>
            ${walletInstructionsHtml}
        </div>
    `;

    // Start 23-minute countdown for confirmations
    const countdownElement = document.getElementById("confirmationCountdown");
    if (countdownElement) {
        startCountdown(23 * 60, countdownElement); // 23 minutes
    }
}

// Initialize loan confirmation page functionality
function initializeLoanConfirmationPage() {
    // Initialize link expiry countdown (30 minutes)
    const linkExpiryCountdown = document.getElementById("linkExpiryCountdown");
    if (linkExpiryCountdown) {
        startLinkExpiryCountdown(30 * 60, linkExpiryCountdown); // 30 minutes
    }

    const nationalIdInputConfirmation = document.getElementById("nationalIdInputConfirmation");
    const confirmLoanPageButton = document.getElementById("confirmLoanPageButton");
    const loanConfirmationClientData = document.getElementById("loanConfirmationClientData");
    const loanConfirmationProofSection = document.getElementById("loanConfirmationProofSection");

    // Check if we're on the loan confirmation page and have a nationalId parameter
    const urlParams = new URLSearchParams(window.location.search);
    const nationalIdFromUrl = urlParams.get("nationalId");

    if (nationalIdFromUrl && loanConfirmationClientData) {
        // Auto-fill and process if nationalId is provided in URL
        if (nationalIdInputConfirmation) {
            nationalIdInputConfirmation.value = nationalIdFromUrl;
        }
        processLoanConfirmation(nationalIdFromUrl);
    }

    if (confirmLoanPageButton && nationalIdInputConfirmation) {
        // Add input validation
        nationalIdInputConfirmation.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            
            if (this.value.length === 14) {
                confirmLoanPageButton.disabled = false;
                confirmLoanPageButton.style.opacity = '1';
            } else {
                confirmLoanPageButton.disabled = true;
                confirmLoanPageButton.style.opacity = '0.6';
            }
        });

        confirmLoanPageButton.addEventListener("click", async function() {
            const nationalId = nationalIdInputConfirmation.value.trim();
            
            if (nationalId.length !== 14) {
                showMessage(loanConfirmationClientData, "يرجى إدخال رقم قومي صحيح مكون من 14 رقم.", "warning");
                loanConfirmationClientData.style.display = "block";
                return;
            }

            processLoanConfirmation(nationalId);
        });

        // Allow Enter key to trigger confirmation
        nationalIdInputConfirmation.addEventListener('keypress', function(event) {
            if (event.key === 'Enter' && this.value.length === 14) {
                confirmLoanPageButton.click();
            }
        });
    }

    async function processLoanConfirmation(nationalId) {
        // Show loading state
        if (confirmLoanPageButton) {
            confirmLoanPageButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحقق...';
            confirmLoanPageButton.disabled = true;
        }

        try {
            const client = await fetchClientData(nationalId);
            if (client) {
                displayLoanConfirmationData(client);
                
                // Start countdowns
                const countdownElement1 = document.getElementById("countdown1");
                const countdownElement2 = document.getElementById("countdown2");

                if (countdownElement1) {
                    startCountdown(40 * 60, countdownElement1); // 40 minutes
                }

                if (countdownElement2) {
                    startCountdown(20 * 60, countdownElement2); // 20 minutes
                }

            } else {
                showMessage(loanConfirmationClientData, "لا توجد بيانات لهذا الرقم القومي. يرجى التأكد من الرقم أو التواصل مع خدمة العملاء.", "error");
                loanConfirmationClientData.style.display = "block";
                if (loanConfirmationProofSection) {
                    loanConfirmationProofSection.style.display = "none";
                }
            }
        } catch (error) {
            showMessage(loanConfirmationClientData, "حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.", "error");
            loanConfirmationClientData.style.display = "block";
        } finally {
            // Reset button state
            if (confirmLoanPageButton) {
                confirmLoanPageButton.innerHTML = '<i class="fas fa-money-bill-transfer"></i> تأكيد تحويل القرض الآن';
                confirmLoanPageButton.disabled = false;
            }
        }
    }
}

// Display loan confirmation data
function displayLoanConfirmationData(client) {
    const loanConfirmationClientData = document.getElementById("loanConfirmationClientData");
    const loanConfirmationProofSection = document.getElementById("loanConfirmationProofSection");
    
    let loanDetails = client["القرض - القرض المراد"] || "غير متاح";
    let loanAmount = "";
    const loanMatch = loanDetails.match(/([\d,]+)/);
    if (loanMatch) {
        loanAmount = loanMatch[1];
    }

    const clientName = client["1. اسم العميل رباعى"] || "عميلنا العزيز";

    loanConfirmationClientData.innerHTML = `
        <div class="success-header">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2>تم تأكيد تحويل القرض بنجاح!</h2>
        </div>
        
        <div class="confirmation-details">
            <p class="congratulations">🎉 تهانينا لك يا <strong>${clientName}</strong>!</p>
            <p class="transfer-info">لقد تم دفع مبلغ القرض <strong>${loanAmount} جنيه مصري</strong> إلى حساب محفظتك.</p>
            
            <div class="timing-info">
                <div class="timing-item">
                    <i class="fas fa-clock"></i>
                    <span>سيتم تسميعه بالحساب بعد مرور <span id="countdown1" class="countdown-inline">40:00</span> دقيقة</span>
                </div>
            </div>
            
            <div class="responsibility-notice">
                <i class="fas fa-exclamation-triangle"></i>
                <p>ومن الآن فصاعداً، أنت مطالب بدفع الأقساط الشهرية في مواعيدها المحددة أو سيكون هناك مسؤولية قانونية على العميل والضامن.</p>
                <p><strong>موعد دفع القسط القادم:</strong> بعد 30 يوماً من يوم دفع القرض للحساب.</p>
            </div>
        </div>
    `;

    // Show sections
    loanConfirmationClientData.style.display = "block";
    if (loanConfirmationProofSection) {
        loanConfirmationProofSection.style.display = "block";
    }

    // Update WhatsApp link
    const whatsappNumber = client["9. رقم واتساب لك للتواصل معك"] || "01221899123";
    const whatsappLink = document.getElementById("whatsappLink");
    if (whatsappLink) {
        const formattedNumber = whatsappNumber.replace(/^0/, "+2");
        whatsappLink.href = `https://wa.me/${formattedNumber}`;
    }

    // Display wallet-specific instructions
    const walletType = client["7. المحفظة المستلمة للقرض باسمك ؟"] || "غير متاح";
    const walletInstructionsDiv = document.getElementById("walletInstructions");
    if (walletInstructionsDiv) {
        let instructions = "";
        if (walletType.includes("فودافون كاش")) {
            instructions = `
                <div class="wallet-instruction-card vodafone">
                    <div class="wallet-header">
                        <i class="fas fa-mobile-alt"></i>
                        <h3>تعليمات فودافون كاش</h3>
                    </div>
                    <div class="instruction-content">
                        <p>اتصل بالكود: <strong class="code">*9*100#</strong></p>
                        <ul>
                            <li>محفظة حديثة (أقل من 3 أشهر): حد أقصى <strong>10,000 جنيه</strong> لكل عملية</li>
                            <li>محفظة قديمة (أكثر من 3 أشهر): حد أقصى <strong>60,000 جنيه</strong> لكل عملية</li>
                            <li>تكلفة التأكيد: <strong>5 جنيه</strong> لكل عملية لصالح فودافون كاش</li>
                        </ul>
                        <p class="note">قسم مبلغ القرض على عدة عمليات حسب الحد الأقصى لمحفظتك</p>
                    </div>
                </div>
            `;
        } else if (walletType.includes("اتصالات كاش")) {
            instructions = `
                <div class="wallet-instruction-card etisalat">
                    <div class="wallet-header">
                        <i class="fas fa-mobile-alt"></i>
                        <h3>تعليمات اتصالات كاش</h3>
                    </div>
                    <div class="instruction-content">
                        <p>اتصل بالكود: <strong class="code">*777*6#</strong></p>
                        <ul>
                            <li>اتبع نفس خطوات فودافون كاش</li>
                            <li>تكلفة التأكيد: <strong>5 جنيه</strong> لكل عملية لصالح اتصالات كاش</li>
                            <li>دعم فني متخصص متاح</li>
                        </ul>
                        <p class="note">قسم مبلغ القرض على عدة عمليات حسب الحد الأقصى لمحفظتك</p>
                    </div>
                </div>
            `;
        } else {
            instructions = `
                <div class="wallet-instruction-card general">
                    <div class="wallet-header">
                        <i class="fas fa-headset"></i>
                        <h3>تعليمات عامة</h3>
                    </div>
                    <div class="instruction-content">
                        <p>يرجى التواصل مع خدمة العملاء للحصول على تعليمات التأكيد الخاصة بمحفظتك.</p>
                        <a href="https://wa.me/201221899123" class="btn btn-secondary">
                            <i class="fab fa-whatsapp"></i>
                            تواصل مع خدمة العملاء
                        </a>
                    </div>
                </div>
            `;
        }
        walletInstructionsDiv.innerHTML = instructions;
    }
}

// Countdown timer function
function startCountdown(duration, display, callback) {
    let timer = duration;
    
    const interval = setInterval(function () {
        const minutes = parseInt(timer / 60, 10);
        const seconds = parseInt(timer % 60, 10);

        const displayMinutes = minutes < 10 ? "0" + minutes : minutes;
        const displaySeconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = displayMinutes + ":" + displaySeconds;

        if (--timer < 0) {
            clearInterval(interval);
            display.textContent = "انتهى الوقت!";
            display.style.color = "#dc2626";
            if (callback) callback();
        }
    }, 1000);

    return interval;
}// Function for loan confirmation page
function confirmLoanTransfer() {
    const nationalId = document.getElementById('nationalIdInputConfirmation').value.trim();
    
    if (!nationalId) {
        alert('يرجى إدخال الرقم القومي');
        return;
    }
    
    if (nationalId.length !== 14) {
        alert('يرجى إدخال رقم قومي صحيح مكون من 14 رقم');
        return;
    }
    
    // Fetch client data from API
    fetch(`/api/client/${nationalId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Client not found');
            }
            return response.json();
        })
        .then(clientData => {
            displayLoanDetails(clientData);
            showProofSection();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('لم يتم العثور على بيانات لهذا الرقم القومي. يرجى التأكد من الرقم والمحاولة مرة أخرى.');
        });
}

function displayLoanDetails(clientData) {
    // Extract client information
    const clientName = clientData['1. اسم العميل'] || clientData['1. اسم العميل '] || clientData['1. اسم العميل رباعى'];
    const loanAmount = clientData['4. مبلغ القرض'] || clientData['4. مبلغ القرض '];
    const loanDuration = clientData['5. مدة القرض'] || clientData['5. مدة القرض '];
    const monthlyInstallment = clientData['6. قيمة القسط الشهري'] || clientData['6. قيمة القسط الشهري '];
    
    // Parse loan details from the combined field if individual fields are not available
    let parsedLoanAmount = loanAmount;
    let parsedLoanDuration = loanDuration;
    let parsedMonthlyInstallment = monthlyInstallment;
    
    if (!loanAmount || !loanDuration || !monthlyInstallment) {
        const loanDetails = clientData["القرض - القرض المراد"] || "";
        const loanMatch = loanDetails.match(/([\d,]+)\s+على\s+(\d+)\s+شهر\s+([\d,]+)\s+قسط/);
        if (loanMatch) {
            parsedLoanAmount = loanMatch[1];
            parsedLoanDuration = loanMatch[2];
            parsedMonthlyInstallment = loanMatch[3];
        }
    }
    
    // Update the display elements
    document.getElementById('clientName').textContent = clientName || 'غير محدد';
    document.getElementById('loanAmount').textContent = parsedLoanAmount ? `${parsedLoanAmount} جنيه مصري` : 'غير محدد';
    document.getElementById('loanDuration').textContent = parsedLoanDuration ? `${parsedLoanDuration} شهر` : 'غير محدد';
    document.getElementById('monthlyInstallment').textContent = parsedMonthlyInstallment ? `${parsedMonthlyInstallment} جنيه مصري` : 'غير محدد';
    
    // Show the loan details section
    document.getElementById('loanDetailsSection').style.display = 'block';
    
    // Scroll to the loan details section
    document.getElementById('loanDetailsSection').scrollIntoView({ behavior: 'smooth' });
}

function showProofSection() {
    // Show the proof section after a short delay
    setTimeout(() => {
        const proofSection = document.getElementById('loanConfirmationProofSection');
        if (proofSection) {
            proofSection.style.display = 'block';
            proofSection.scrollIntoView({ behavior: 'smooth' });
            
            // Start countdowns
            const countdownElement1 = document.getElementById("countdown1");
            const countdownElement2 = document.getElementById("countdown2");

            if (countdownElement1) {
                startCountdown(40 * 60, countdownElement1); // 40 minutes
            }

            if (countdownElement2) {
                startCountdown(20 * 60, countdownElement2); // 20 minutes
            }
        }
    }, 1000);
}nst messageClass = type === "error" ? "error-message" : 
                        type === "warning" ? "warning-message" : "info-message";
    
    const icon = type === "error" ? "fas fa-exclamation-circle" : 
                 type === "warning" ? "fas fa-exclamation-triangle" : "fas fa-info-circle";

    container.innerHTML = `
        <div class="message ${messageClass}">
            <i class="${icon}"></i>
            <p>${message}</p>
        </div>
    `;
}

// Add CSS for messages and additional styling
const additionalCSS = `
<style>
.message {
    padding: 20px;
    border-radius: 12px;
    margin: 20px 0;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 500;
}

.error-message {
    background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
    color: #991b1b;
    border: 2px solid #f87171;
}

.warning-message {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    color: #92400e;
    border: 2px solid #fbbf24;
}

.info-message {
    background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
    color: #1e40af;
    border: 2px solid #3b82f6;
}

.client-info-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #e2e8f0;
}

.verification-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
    color: #166534;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 0.9em;
    font-weight: 600;
    border: 1px solid #86efac;
}

.client-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.info-item {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 20px;
    border-radius: 12px;
    border-right: 4px solid #3b82f6;
}

.info-label {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.95em;
    color: #64748b;
    margin-bottom: 8px;
    font-weight: 600;
}

.info-value {
    font-size: 1.1em;
    color: #1e40af;
    font-weight: 700;
}

.loan-details {
    background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
    padding: 25px;
    border-radius: 15px;
    margin: 25px 0;
    border: 2px solid #3b82f6;
}

.loan-details h4 {
    color: #1e40af;
    font-size: 1.4em;
    margin-bottom: 20px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
}

.loan-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.loan-info-item {
    background: rgba(255, 255, 255, 0.8);
    padding: 15px;
    border-radius: 10px;
    text-align: center;
}

.loan-info-item.highlight {
    background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
    color: #fff;
}

.loan-label {
    font-size: 0.9em;
    margin-bottom: 5px;
    font-weight: 500;
}

.loan-value {
    font-size: 1.3em;
    font-weight: 700;
}

.action-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
    margin-top: 30px;
}

.success-header {
    text-align: center;
    margin-bottom: 30px;
}

.success-icon {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
}

.success-icon i {
    font-size: 3em;
    color: #fff;
}

.congratulations {
    font-size: 1.4em;
    color: #166534;
    font-weight: 700;
    text-align: center;
    margin-bottom: 15px;
}

.transfer-info {
    font-size: 1.2em;
    color: #1e40af;
    font-weight: 600;
    text-align: center;
    margin-bottom: 25px;
}

.timing-info {
    background: linear-gradient(135deg, #e0f2f1 0%, #f1f8e9 100%);
    padding: 20px;
    border-radius: 12px;
    margin: 20px 0;
    border: 2px solid #4caf50;
}

.timing-item {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.1em;
    color: #2e7d32;
    font-weight: 600;
}

.countdown-inline {
    background: #2e7d32;
    color: #fff;
    padding: 4px 8px;
    border-radius: 6px;
    font-family: 'Courier New', monospace;
    font-weight: 700;
}

.responsibility-notice {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    padding: 20px;
    border-radius: 12px;
    border: 2px solid #f59e0b;
    margin: 20px 0;
}

.responsibility-notice i {
    color: #d97706;
    font-size: 1.5em;
    margin-bottom: 10px;
}

.responsibility-notice p {
    color: #92400e;
    font-weight: 600;
    margin-bottom: 10px;
}

.wallet-instruction-card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 25px;
    margin: 20px 0;
    border: 2px solid;
}

.wallet-instruction-card.vodafone {
    border-color: #dc2626;
}

.wallet-instruction-card.etisalat {
    border-color: #d97706;
}

.wallet-instruction-card.general {
    border-color: #3b82f6;
}

.wallet-instruction-card .wallet-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.wallet-instruction-card.vodafone .wallet-header h3 {
    color: #dc2626;
}

.wallet-instruction-card.etisalat .wallet-header h3 {
    color: #d97706;
}

.wallet-instruction-card.general .wallet-header h3 {
    color: #3b82f6;
}

.code {
    background: #1e293b;
    color: #fbbf24;
    padding: 5px 10px;
    border-radius: 6px;
    font-family: 'Courier New', monospace;
    font-size: 1.2em;
}

.instruction-content ul {
    list-style: none;
    padding: 0;
    margin: 15px 0;
}

.instruction-content ul li {
    background: rgba(59, 130, 246, 0.1);
    padding: 10px 15px;
    border-radius: 8px;
    margin-bottom: 8px;
    border-right: 3px solid #3b82f6;
}

.note {
    background: linear-gradient(135deg, #e0f2f1 0%, #f1f8e9 100%);
    padding: 12px 15px;
    border-radius: 8px;
    color: #2e7d32;
    font-weight: 600;
    margin-top: 15px;
    border-right: 3px solid #4caf50;
}

@media (max-width: 768px) {
    .client-info-grid {
        grid-template-columns: 1fr;
    }
    
    .loan-info-grid {
        grid-template-columns: 1fr;
    }
    
    .action-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .client-info-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
}
</style>
`;

// Inject additional CSS
document.head.insertAdjacentHTML('beforeend', additionalCSS);


// Link expiry countdown function
function startLinkExpiryCountdown(seconds, element) {
    let timeLeft = seconds;
    let interval;

    function updateCountdown() {
        const minutes = Math.floor(timeLeft / 60);
        const secs = timeLeft % 60;
        element.textContent = `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

        if (timeLeft <= 0) {
            clearInterval(interval);
            expirePage();
            return;
        }

        timeLeft--;
    }

    // Start countdown immediately
    updateCountdown();
    interval = setInterval(updateCountdown, 1000);

    // Force expire after 25 minutes
    setTimeout(() => {
        expirePage();
    }, 25 * 60 * 1000); // 25 minutes

    function expirePage(customMessage = null) {
        clearInterval(interval);
        
        // Create expired overlay
        const overlay = document.createElement('div');
        overlay.className = 'expired-overlay';
        
        const message = document.createElement('div');
        message.className = 'expired-message';
        message.innerHTML = `
            <h2><i class="fas fa-times-circle"></i> انتهت صلاحية الرابط</h2>
            <p>${customMessage || 'انتهت صلاحية هذا الرابط. يرجى التواصل مع خدمة العملاء للحصول على رابط جديد.'}</p>
            <a href="https://wa.me/201221899123" class="btn btn-primary">
                <i class="fab fa-whatsapp"></i>
                التواصل مع خدمة العملاء
            </a>
        `;
        
        overlay.appendChild(message);
        document.body.appendChild(overlay);
        
        // Disable all form elements
        const inputs = document.querySelectorAll('input, button');
        inputs.forEach(input => {
            input.disabled = true;
        });
        
        // Add expired class to warning
        const expiryWarning = document.querySelector('.expiry-warning');
        if (expiryWarning) {
            expiryWarning.classList.add('link-expired');
        }
    }
}

